#pragma once
#include <SFML/Graphics.hpp>
class WelcomeWindow
{
	sf::Text welcome;
	sf::Text enterName;
	sf::Text input;

};