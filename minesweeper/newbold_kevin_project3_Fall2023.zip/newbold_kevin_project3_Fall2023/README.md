Name: Kevin Newbold
Section: 12148
UFL email: kevin.newbold@ufl.edu
System: Windows 11
Compiler: Microsoft Visual C++, C++14 Standard
SFML version: 2.6.1
IDE: Visual Studio 2019
Other notes: None